import random

META = 250

producao = []
historico = []

def media(lista):
    return sum(lista) / len(lista)

while True:
    
    producao.clear()  

    for i in range(10):
        producao.append(round(random.uniform(100, 400), 2))

    print("\nProdução por hora:")
    print(producao)

    m = media(producao)
    historico.append(m)

    print(f"\nMédia atual: {m:.2f}")

    # EFICIÊNCIA
    eficiencia = (m / META) * 100
    print(f"Eficiência: {eficiencia:.2f}%")

    # COMPARAÇÃO COM META
    if eficiencia >= 100:
        print("DESEMPENHO EXCELENTE")
    elif eficiencia >= 90:
        print("DESEMPENHO BOM")
    else:
        print("DESEMPENHO BAIXO")

    print("\nHistórico de médias:")
    print(historico)

    media_geral = media(historico)
    print(f"\nMédia geral: {media_geral:.2f}")

    input("\nPressione ENTER...")