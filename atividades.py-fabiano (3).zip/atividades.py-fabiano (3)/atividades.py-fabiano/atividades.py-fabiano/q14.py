# Controle de Produtividade da Linha

import random

META = 250

producao = []
historico = []  # guarda todas as médias

def media(lista):
    return sum(lista) / len(lista)

while True:
    
    producao.clear()  

    for i in range(10):
        producao.append(round(random.uniform(100, 400), 2))

    print("\nProdução por hora:")
    print(producao)

    m = media(producao)
    historico.append(m)  # salva no histórico

    print(f"\nMédia atual: {m:.2f}")

    if m >= META:
        print("META ATINGIDA")
    else:
        print("META NÃO ATINGIDA")

    # MOSTRA HISTÓRICO
    print("\nHistórico de médias:")
    print(historico)
    media_geral = media(historico)
    print(f"\nMédia geral: {media_geral:.2f}")

    input("\nPressione ENTER...")