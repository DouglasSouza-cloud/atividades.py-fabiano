#Monitoramento de Temperatura
import random

temperaturas = []

while True:
    temperaturas.clear()  # limpa a lista a cada ciclo

    # Gera 20 valores aleatórios 
    for i in range(100):
        
        temp = round(random.uniform(20.0, 100.0), 2)
        if temp >= 80:
            temperaturas.append(temp)

    print("\nTemperaturas coletadas:")
    print(temperaturas)

    # Verifica superaquecimento
    for t in temperaturas:
        if t >= 80:
            print(f"ALERTA: Temperatura acima de 80°C >> {t}°C")

    input("\nPressione ENTER para coletar novos dados...")