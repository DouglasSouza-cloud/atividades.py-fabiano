#Monitoramento de Câmara Fria
import random

temperaturas = []

while True:
    temperaturas.clear()  # limpa a lista a cada ciclo

    # Gera 20 valores aleatórios 
    for i in range(20):
        temp = round(random.uniform(0, 20), 2)
        temperaturas.append(temp)

    print("\nTemperaturas coletadas:")
    print(temperaturas)

    # Verifica aquecimento 
    for t in temperaturas:
        if t > 10:
            print(f"ALERTA: Temperatura acima de 10°C >> {t}°C")

    input("\nPressione ENTER para coletar novos dados...")