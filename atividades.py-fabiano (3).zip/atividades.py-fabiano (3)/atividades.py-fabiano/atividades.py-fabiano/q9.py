#Controle de Produtividade da Linha
import random

META = 250

producao = []

def media(lista):
    return sum(lista) / len(lista)

while True:
    
    producao.clear
    
    for i in range(20):
        producao.append(round(random.uniform(100, 400), 2))

    print("\nProdução por hora:")
    print(producao)

    m = media(producao)
    print(f"\nMédia: {m: .2f}")

    if m >= META:
        print("META ATINGIDA")
    else:
        print("META NÃO ATINGIDA")

    for p in producao:
        if p < 150:
            print(f"ALERTA: {p}")

    input("\nPressione ENTER...")