# Controle de Pressão em Sistema Hidráulico

import random
import time
import os

pressao = []

while True:
    pressao.clear()

    # Limpa a tela
    os.system('cls')

    # Gera 20 valores aleatórios
    for i in range(20):
        pres = round(random.uniform(100, 400), 2)
        pressao.append(pres)

    print("Leitura em tempo real da Pressão:\n")

    # Exibição contínua
    for p in pressao:
        print(f"{p} bar")

        if p > 350:
            print(f"ALERTA: Pressão Acima do intervalo seguro >> {p} bar")

        time.sleep(0.8)  
    time.sleep(2)  