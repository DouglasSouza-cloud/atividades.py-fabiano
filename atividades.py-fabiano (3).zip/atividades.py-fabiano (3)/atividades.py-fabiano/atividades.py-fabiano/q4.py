#Controle Qualidade (pH)
import random

ph = []

while True:
    ph.clear()  # limpa a lista a cada ciclo

    # Gera 20 valores aleatórios 
    for i in range(20):
        phh = round(random.uniform(5, 9), 2)
        ph.append(phh)

    print("\nTemperaturas coletadas:")
    print(ph)

    # Verifica pH
    for p in ph:
        if p < 6 or p > 8:
            print(f"ALERTA: pH fora da faixa ideal de 6 a 8 >> pH {p}")

    input("\nPressione ENTER para coletar novos dados...")