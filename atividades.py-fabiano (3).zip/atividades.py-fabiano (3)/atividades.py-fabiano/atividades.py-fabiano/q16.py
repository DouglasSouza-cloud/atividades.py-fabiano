#Monitoramento de Temperatura
import random
import time
temperaturas = []

while True:
    temperaturas.clear()  # limpa a lista a cada ciclo
    print("Iniciando Sistema...")
    time.sleep(1)
    
    # Gera 20 valores aleatórios 
    for i in range(20):
        temp = round(random.uniform(20.0, 100.0), 2)
        temperaturas.append(temp)
        
    print("Gerando dados e enviando para a Nuvem...")
    time.sleep(2)
    print("Envio completo.\n")
    print("\nTemperaturas coletadas:")
    print(temperaturas)

    # Verifica superaquecimento
    for t in temperaturas:
        if t > 80:
            print(f"ALERTA: Temperatura acima de 80°C >> {t}°C")

    input("\nPressione ENTER para coletar novos dados...")