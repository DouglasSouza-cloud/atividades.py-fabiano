#Controle de Nível de Tanque
import random

nivel = []

while True:
    nivel.clear()  # limpa a lista a cada ciclo

    # Gera 20 valores aleatórios 
    for i in range(20):
        niv = round(random.uniform(10, 100), 2)
        nivel.append(niv)

    print("\nTemperaturas coletadas:")
    print(nivel)

    # Verifica pH
    for n in nivel:
        if n < 20 or n > 90:
            print(f"ALERTA: Nível crítico fora da faixa ideal de 20% a 90% >> {n}%")

    input("\nPressione ENTER para coletar novos dados...")