#Consumo de Energia
import random

consumo = []

while True:
    consumo.clear()  # limpa a lista a cada ciclo

    # Gera 20 valores aleatórios 
    for i in range(20):
        cons = round(random.uniform(100, 1000 ), 2)
        consumo.append(cons)

    print("\nTemperaturas coletadas:")
    print(consumo)

    # Verifica Consumo Energético
    for c in consumo:
        if c > 1000:
            print(f"ALERTA: Consumo Energético acima de 1000 kWh >> {c}kWh")

    input("\nPressione ENTER para coletar novos dados...")