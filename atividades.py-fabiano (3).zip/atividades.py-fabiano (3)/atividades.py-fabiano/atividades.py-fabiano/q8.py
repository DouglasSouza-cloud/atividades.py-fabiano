#Controle de Pressão em Sistema Hidráulico

import random

pressao = []

while True:
    pressao.clear()  # limpa a lista a cada ciclo

    # Gera 20 valores aleatórios 
    for i in range(20):
        pres = round(random.uniform(100, 400), 2)
        pressao.append(pres)

    print("\nTemperaturas coletadas:")
    print(pressao)

    # Verifica pH
    for p in pressao:
        if p > 350:
            print(f"ALERTA: Pressão Acima do intervalo seguro >> {p}bar")

    input("\nPressione ENTER para coletar novos dados...")


