# Simulação de Sistema Industrial Completo

import random
import time

META = 250

# Banco de dados
banco = []

# SENSOR 
def sensor():
    dados = []
    for i in range(10):
        dados.append(round(random.uniform(100, 400), 2))
    return dados

# CLP
def clp(dados):
    tratados = []

    for valor in dados:
        if valor < 120:
            print(f"ALERTA >> Valor muito baixo: {valor}")
        elif valor > 380:
            print(f"ALERTA >> Valor muito alto: {valor}")

        tratados.append(valor)

    return tratados

# SUPERVISÓRIO 
def supervisório(dados):
    print("\nDados do processo:")
    print(dados)

    media = sum(dados) / len(dados)
    print(f"Média: {media:.2f}")

    if media >= META:
        print("STATUS: PRODUÇÃO OK")
    else:
        print("STATUS: PRODUÇÃO BAIXA")

    return media

# BANCO 
def salvar(media):
    banco.append(media)

# DASHBOARD
def dashboard():
    print("\n===== DASHBOARD FINAL =====")

    if len(banco) == 0:
        print("Sem dados")
        return

    media_geral = sum(banco) / len(banco)
    maior = max(banco)
    menor = min(banco)

    print(f"Médias registradas: {banco}")
    print(f"Média geral: {media_geral:.2f}")
    print(f"Maior média: {maior}")
    print(f"Menor média: {menor}")

# LOOP PRINCIPAL
while True:
    
    # SENSOR
    dados = sensor()

    # CLP
    dados_tratados = clp(dados)

    # SUPERVISÓRIO
    media = supervisório(dados_tratados)

    # BANCO
    salvar(media)

    # parar depois de alguns ciclos
    if len(banco) == 5:
        break

    time.sleep(2)

# DASHBOARD FINAL
dashboard()
