import random

temperaturas = []

def media(lista):
    return sum(lista) / len(lista)

while True:
    temperaturas.clear()

    for i in range(20):
        temp = round(random.uniform(20.0, 100.0), 2)
        temperaturas.append(temp)

    print("\nTemperaturas coletadas:")
    print(temperaturas)

    m = media(temperaturas)
    print(f"Média: {m:.2f}°C")

    for t in temperaturas:
        if t > 80:
            print(f"ALERTA CRÍTICO >> {t}°C")

        if t > m + 15:
            print(f"ANOMALIA DETECTADA >> {t}°C")

    if temperaturas[-1] > temperaturas[0] + 20:
        print("ALERTA: Tendência de aumento de temperatura!")

    input("\nPressione ENTER para continuar...")