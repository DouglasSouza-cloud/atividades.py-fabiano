#Monitoramento de Temperatura
import random
import sys

temperaturas = []

while True:
    temperaturas.clear()  # limpa a lista a cada ciclo

    # Gera 20 valores aleatórios 
    for i in range(1):
        temp = round(random.uniform(20, 100), 2)
        temperaturas.append(temp)

    print("\nTemperaturas coletadas:")
    print(temperaturas)

    # Verifica superaquecimento
    for t in temperaturas:
        if t > 80:
            print(f"ALERTA: Temperatura acima de 80°C >> {t}°C")
            print("Desligando máquina...")
            sys.exit()
            
    input("\nPressione ENTER para coletar novos dados...")