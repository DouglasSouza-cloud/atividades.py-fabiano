#Monitoramento de Temperatura

import random

temperaturas = []

while True:
    alertas = 0 
    temperaturas.clear()  # limpa a lista a cada ciclo

    # Gera 20 valores aleatórios 
    for i in range(10):
        temp = round(random.uniform(10.0, 100.0), 2)
        temperaturas.append(temp)

    print("\nTemperaturas coletadas:\n")
    print(temperaturas)

    # Verifica superaquecimento
    for t in temperaturas:
        
        if t >= 20 and t <= 50:
            print(f"Máquina Estável, Normal >> {t}°C\n")
            
        if t > 50 and t < 80:
            print(f"\nAlerta de temperatura acima do normal >> {t}C°\n")
            
        if t >= 80:
            alertas += 1
            print(f"\nALERTA DE TEMPERATURA EM NÍVEL CRÍTICO >> {t}C°\n")
            
    print(f"Total de Alertas:{alertas}")    

    input("\nPressione ENTER para coletar novos dados...")