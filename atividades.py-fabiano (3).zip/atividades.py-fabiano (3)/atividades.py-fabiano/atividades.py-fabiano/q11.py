#Monitoramento de Temperatura

import random

temperaturas = []

while True:
    alertas = 0 
    temperaturas.clear()  # limpa a lista a cada ciclo

    # Gera 20 valores aleatórios 
    for i in range(10):
        temp = round(random.uniform(10.0, 100.0), 2)
        temperaturas.append(temp)

    print("\nTemperaturas coletadas:")
    print(temperaturas)

    # Verifica superaquecimento
    for t in temperaturas:
        
        if t > 80 or t < 10:
            alertas += 1
            print(f"ALERTA DE TEMPERATURA >> {t}°C")
    print(f"Total de Alertas:{alertas}")    

    input("\nPressione ENTER para coletar novos dados...")