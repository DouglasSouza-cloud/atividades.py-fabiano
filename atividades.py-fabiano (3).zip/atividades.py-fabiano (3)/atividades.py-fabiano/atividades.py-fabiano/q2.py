#Controle de Velocidade de Esteira
import random

velocidades = []

while True:
    velocidades.clear()  # limpa a lista a cada ciclo

    # Gera 20 valores aleatórios 
    for i in range(20):
        velo = round(random.uniform(0.1, 0.8), 2)
        velocidades.append(velo)

    print("\nVelocidades coletadas:")
    print(velocidades)

    # Verifica Velocidade Baixa
    for v in velocidades:
        if v > 0.5:
            print(f"ALERTA: Velocidade abaixo de 0.5 m/s >> {v}m/s")

    input("\nPressione ENTER para coletar novos dados...")