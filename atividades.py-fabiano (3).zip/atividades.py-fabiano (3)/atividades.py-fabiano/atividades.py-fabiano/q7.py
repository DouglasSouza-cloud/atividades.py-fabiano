#Controle de Vibração de Motor

import random

vibracao = []

while True:
    vibracao.clear()  # limpa a lista a cada ciclo

    # Gera 20 valores aleatórios 
    for i in range(20):
        vib = round(random.uniform(1.8, 8.1), 2)
        vibracao.append(vib)

    print("\nTemperaturas coletadas:")
    print(vibracao)

    # Verifica pH
    for v in vibracao:
        if v > 7.1:
            print(f"ALERTA: Velocidade de Vibração Critica >> {v}mm/s RMS")

    input("\nPressione ENTER para coletar novos dados...")


