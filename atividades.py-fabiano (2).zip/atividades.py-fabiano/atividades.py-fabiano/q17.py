#Controle de Produtividade da Linha
import random

META = 250

producao = []

def media(lista):
    return sum(lista) / len(lista)


while True:
    
    producao.clear()
    
    for i in range(10):
        producao.append(round(random.uniform(100, 400), 2))

    print("\nProdução por hora:")
    print(producao) 

    m = media(producao)
    print(f"\nMédia: {m: .2f}")
    
    
    
    print(max(producao))
    print(min(producao))
        
        

    input("\nPressione ENTER...")